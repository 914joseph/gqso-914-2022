# Calculadora API

Este repositório contém o código da API calculadora. Disciplina GQSO, ano 2022.

Autores/as:

* Daniel Fireman
* Eduardo Lúcio

Estudem e façam a atividade!!!!!!!!!

Vamos testar a criação e utilização de ramos!


Criando o arcabouço usando maven archetypes

```
mvn archetype:generate -B -DgroupId=com.danielfireman.ifal.calcapi -DartifactId=server -Dversion=1.0 -DarchetypeArtifactId=jooby-archetype -DarchetypeGroupId=org.jooby -DarchetypeVersion=1.6.6
```

Documentação:

https://jooby.io/v1/doc/#routes-request-handling

https://jooby.io/v1/apidocs/org/jooby/request

Coverage: https://medium.com/@karlrombauts/setting-up-unit-testing-for-java-in-vs-code-with-maven-3dc75579122f